<?php include("libs/config.php")?>
<?php
if(isset($_POST["signup"]))
{
	$fullname = $_POST["fullname"];
	$address = $_POST["address"];
	$number = $_POST["number"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	$designation = $_POST["designation"];
	$status = '0';
	$createddate = date('d-M-Y');
	
	$query = "INSERT INTO `login`(`fullname`, `address`, `number`, `email`, `password`, `designation`, `usertype`, `status`, `createddate`) VALUES ('$fullname','$address','$number','$email','$password','$designation','user','$status','$createddate')";
	$que = mysql_query($query);
	if($que)
	{
		echo '<script>alert ("New User is Created")</script>';
	}else
	{
		echo '<script>alert ("Something Went Wrong")</script>';
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Sign Up</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="icon" type="image/png" href="images/icons/favicon.ico" />

<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">

<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">

<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">

<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">

<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">

<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">

<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">

</head>
<body>
<div class="limiter">
<form method="POST" action="">
<div class="container-login100">
<div class="wrap-login100">
<form class="login100-form validate-form" action="index.php">
<span class="login100-form-title p-b-26">
Sign Up
</span>

<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="fullname">
<span class="focus-input100" data-placeholder="Full Name"></span>
</div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="address">
<span class="focus-input100" data-placeholder="Address"></span>
</div>
<div class="wrap-input100 validate-input">
<input class="input100" type="number" name="number">
<span class="focus-input100" data-placeholder="Phone No"></span>
</div>
<div class="wrap-input100 validate-input" data-validate="Valid email is: a@b.c">
<input class="input100" type="text" name="email">
<span class="focus-input100" data-placeholder="Email"></span>
</div>
<div class="wrap-input100 validate-input" data-validate="Enter password">
<span class="btn-show-pass">
<i class="zmdi zmdi-eye"></i>
</span>
<input class="input100" type="password" name="password">
<span class="focus-input100" data-placeholder="Password"></span>
</div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="designation">
<span class="focus-input100" data-placeholder="Designation"></span>
</div>
<div class="container-login100-form-btn">
<div class="wrap-login100-form-btn">
<div class="login100-form-bgbtn"></div>
<button type="submit" name="signup" id="signup" class="login100-form-btn">
Sign Up
</button>
</div>
</div>
</form>
<div class="text-center p-t-115">
<span class="txt1">
Already have an account?
</span>
<a class="txt2" href="index.php">
Sign In
</a>
</div>
</div>
</div>
</form>
</div>
<div id="dropDownSelect1"></div>

<script src="vendor/jquery/jquery-3.2.1.min.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="vendor/animsition/js/animsition.min.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="vendor/bootstrap/js/popper.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="vendor/select2/select2.min.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="vendor/daterangepicker/moment.min.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>
<script src="vendor/daterangepicker/daterangepicker.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="vendor/countdowntime/countdowntime.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script src="js/main.js" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="9d651d7f3d50ebfeda25a027-text/javascript"></script>
<script type="9d651d7f3d50ebfeda25a027-text/javascript">
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
	</script>
<script src="js/rocket-loader.min.js" data-cf-settings="9d651d7f3d50ebfeda25a027-|49" defer=""></script></body>

</html>

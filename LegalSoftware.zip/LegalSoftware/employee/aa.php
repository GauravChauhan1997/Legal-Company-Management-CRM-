$sdss = mysql_query("SELECT * FROM addnewemployee WHERE addnewemployeeid = '$user_check'");
	$abccc = mysql_fetch_assoc($sdss);
	$addnewemployeeid = $abccc["addnewemployeeid"];
	$sds = mysql_query("SELECT * FROM addnewclient WHERE newclientrefid = '$addnewemployeeid'");
	$abcc = mysql_fetch_assoc($sds);
	$clientcode = $abcc["clientcode"];
	$sd = mysql_query("SELECT * FROM newdocket WHERE code = '$clientcode'");
	$abc = mysql_fetch_assoc($sd);
	$newdocketid = $abc["newdocketid"];
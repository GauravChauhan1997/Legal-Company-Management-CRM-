<?php include("header.php")?>
<?php
if(isset($_POST["abc"]))
{
$code = $_POST["code"];
$status = '0';
$createddate = date('d-M-Y');

$queryyy = mysql_query("select * FROM addnewemployee where addnewemployeeid = '$user_check'");
$roww = mysql_fetch_assoc($queryyy);
$name = $roww["fname"];
$name2 = $roww["lname"];
$query2 = "INSERT INTO `newdocket`(`code`,`create2`, `create3`,`docketrefid`, `status`, `createddate`) VALUES ('$code','$name','$name2','$user_check','$status','$createddate')";
$que = mysql_query($query2);
if($que)
{
	echo '<script>alert ("New Docket is Created")</script>';
}else
{
	echo '<script>alert ("Something Went Wrong")</script>';
}

}
?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM newdocket WHERE `newdocketid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of Dockets
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
			  <!--a href="#"><button type="button" style="margin:5px" class="btn btn-success" data-toggle="modal" data-target="#myModal">Create New Docket</button></a-->
            
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sr no</th>
                  <th>Full Name</th>
				  <th>Address</th>	
                  <th>Contact</th>				  
                  <th>Client Code</th>
				  <th>Created By</th>
				  <th>Created On</th>
				  <th>Action</th>
                </tr>
                </thead>
                <tbody>
<?php
$count = 1;

$query5 = mysql_query("select * from addnewclient AS anc INNER JOIN newdocket AS nd ON anc.addnewclientid = nd.code WHERE assign= '$user_check' ORDER BY newdocketid DESC");
while($row = mysql_fetch_array($query5))
{  	
?>
                <tr>
				  <td><?php echo $count?></td>
                  <td><b><a href="existingclientsview.php?view=<?php echo $row["addnewclientid"]?>"><?php echo $row["cfname"]?> <?php echo $row["cfullname"]?></a></b></td>
                  <td><?php echo $row["caddress"]?></td>
				  <td><?php echo $row["ccontact"]?></td>
                  <td style="color:green"><b><?php echo $row["clientcode"]?></b></td>		
				  <td><?php echo $row["create2"]?></td>	
				  <td><?php echo $row["ccreateddate"]?></td>						  
                  <td>				                     
                    <a href="allcases.php?view=<?php echo $row["newdocketid"]?>"><b style="color:orange">All Cases</b></a>
   
					  <!--a href="docket.php?del=<?php echo $row["newdocketid"]?>"><button type="button" class="btn btn-danger" name="delete" id="delete">Delete</button></a-->
				  
				  </td>
				  
                </tr>
<?php
$count++;
}
?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php include("footer.php")?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
	  <form method="POST">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#3c8dbc">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color:white"><b>Create Docket</b></h4>
        </div>
        <div class="modal-body">
          <div class="row">
		     <div class="col-md-12">
			      <label>Client Code</label>
			      <select class="form-control select2" name="code" id="code">
<?php
$doc = mysql_query("select * FROM addnewclient WHERE assign = '$user_check' ORDER BY addnewclientid DESC");
while($docs = mysql_fetch_array($doc))
{
?>
				      <option value="<?php echo $docs["addnewclientid"]?>"><?php echo $docs["clientcode"]?></option>
<?php
}
?>
				  </select>
			 </div>
		  </div>
        </div>
        <div class="modal-footer">
          <center><button type="submit" class="btn btn-primary" name="abc" id="abc">Create</button></center>
        </div>
      </div>
      </form>
    </div>
  </div>
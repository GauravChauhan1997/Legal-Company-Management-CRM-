<?php include("header.php")?>

<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM newcase WHERE `newcaseid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Active Cases
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sr no</th>
                  <th>Docket No.</th>
                  <th>Application No.</th>
                  <th>Applicant</th>
				  <th>Created By</th>
				  <th>Created On</th>
				  <th>Docs</th>
				  <th>Status</th>
                </tr>
                </thead>
                <tbody>
<?php
$count = 1;
$details = mysql_query("SELECT * FROM newcase WHERE task = 'Active' && newcaserefid2 = '$user_check'");   	
$detailss= mysql_query("SELECT * FROM newdocket AS nd INNER JOIN addnewclient AS anc ON nd.code = anc.addnewclientid WHERE docketrefid = '$user_check'");
while($row_users = mysql_fetch_array($detailss))
			{
			   $clientcode = $row_users["clientcode"];
						
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["newcaserefid"];
							$appno = $row_user["appno"];
							$ip = $row_user["ip"];
							$applicant = $row_user["applicant"];
							$create2 = $row_user["create2"];
							$create3 = $row_user["create3"];
							$createddate = $row_user["createddate"];
							$task = $row_user["task"];
							$keyy = $row_user["keyy"];
		
?>
               <tr>
				  <td><?php echo $count?></td>
                  <td><b><a href="caseview.php?view=<?php echo $row_user["newcaseid"]?>"><?php echo $ip?> <?php echo $clientcode?> <?php echo $keyy?></a></b></td>
                  <td><?php echo $appno?></td>
                  <td><?php echo $applicant?></td>
				  <td><?php echo $create2?> <?php echo $create3?></td>
                  <td><?php echo $createddate?></td>
                  <td>
				      <a href="AddImagesdetails2.php?view=<?php echo $row_user["newcaseid"]?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
				  </td>					  
                  <td style="color:blue"><?php echo $task?></td>				  
                  
                </tr>
<?php
$count++;
		  }
			}
?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php include("footer.php")?>
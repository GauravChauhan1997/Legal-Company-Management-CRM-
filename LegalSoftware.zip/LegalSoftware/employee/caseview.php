<?php include("header.php")?>
<?php

if(isset($_POST["update"]))
	 {
			
		    $id = $_POST["id"];
			$applicant = $_POST["applicant"];
			$appno = $_POST["appno"];
			$title = $_POST["title"];
			$filedon = $_POST["filedon"];
			$prioritydate = $_POST["prioritydate"];
			$country = $_POST["country"];
			$entity = $_POST["entity"];
			$ip = $_POST["ip"];
			$sip = $_POST["sip"];
			$remark = $_POST["remark"];
			$task = $_POST["task"];

		 $query = "UPDATE `newcase` SET `applicant`='$applicant',`appno`='$appno',`title`='$title',`filedon`='$filedon',`prioritydate`='$prioritydate',`country`='$country',`entity`='$entity',`ip`='$ip',`sip`='$sip',`remark`='$remark',`task`='$task' WHERE newcaseid = '$id'";
		 
		 $que = mysql_query($query);
		 if($que)
		 {
			 echo'<script>alert("Case Details Updated")</script>';
		 }
		 else{
			 echo'<script>alert("Something Went Wrong")</script>';
		 }

	 }


if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM newcase WHERE `newcaseid` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			
				
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["newcaseid"];
					        $applicant = $row_user["applicant"];
							$title = $row_user["title"];
							$filedon = $row_user["filedon"];
							$prioritydate = $row_user["prioritydate"];
							$country = $row_user["country"];
							$entity = $row_user["entity"];
							$ip = $row_user["ip"];
							$sip = $row_user["sip"];
							$remark = $row_user["remark"];
							$appno = $row_user["appno"];
							$task = $row_user["task"];
							$status = $row_user["status"];
							$createdon = $row_user["createdon"];
					 
						 if($entity == "Individual / Micro")
						 {
							 $Individual = 'selected';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
						 else if($entity == "Small Entity" || $entity == "Small Entity")
						 {
							 $Individual = '';
							 $SmallEntity = 'selected';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
                         else if($entity == "Large Entity" || $entity == "Large Entity")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = 'selected';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
                         else if($entity == "Law Firm" || $entity == "Law Firm")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = 'selected';
							 $IPFirm = '';
						 }
                         else if($entity == "IP Firm" || $entity == "IP Firm")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = 'selected';
						 }
						 
						 
						 if($ip == "PT" || $ip == "PT")
						 {
							 $PT = 'selected';
							 $CR = '';
							 $TM = '';                       
							 $DN = '';
						 }
						 else if($ip == "CR" || $ip == "CR")
						 {
							 $PT = '';
							 $CR = 'selected';
							 $TM = '';                       
							 $DN = '';
						 }
						 else if($ip == "TM" || $ip == "TM")
						 {
							 $PT = '';
							 $CR = '';
							 $TM = 'selected';                       
							 $DN = '';
						 }
						 else if($ip == "DN" || $ip == "DN")
						 {
							 $PT = '';
							 $CR = '';
							 $TM = '';                       
							 $DN = 'selected';
						 }
						 
						 
						 if($sip == "New Application" || $sip == "New Application")
						 {
							 $NewApplication = 'selected';
							 $Search = '';
							 $Renewal = '';                       
							 $Restoration = '';
							 $Others = '';                       
							 $Assignment = '';
						 }
						 else if($sip == "Search" || $sip == "Search")
						 {
							 $NewApplication = '';
							 $Search = 'selected';
							 $Renewal = '';                       
							 $Restoration = '';
							 $Others = '';                       
							 $Assignment = '';
						 }
						 else if($sip == "Renewal" || $sip == "Renewal")
						 {
							 $NewApplication = '';
							 $Search = '';
							 $Renewal = 'selected';                       
							 $Restoration = '';
							 $Others = '';                       
							 $Assignment = '';
						 }
						 else if($sip == "Restoration" || $sip == "Restoration")
						 {
							 $NewApplication = '';
							 $Search = '';
							 $Renewal = '';                       
							 $Restoration = 'selected';
							 $Others = '';                       
							 $Assignment = '';
						 }
						 else if($sip == "Others" || $sip == "Others")
						 {
							 $NewApplication = '';
							 $Search = '';
							 $Renewal = '';                       
							 $Restoration = '';
							 $Others = 'selected';                       
							 $Assignment = '';
						 }
						 else if($sip == "Assignment" || $sip == "Assignment")
						 {
							 $NewApplication = '';
							 $Search = '';
							 $Renewal = '';                       
							 $Restoration = '';
							 $Others = '';                       
							 $Assignment = 'selected';
						 }
						 if($task == "Active" || $task == "Active")
						 {
							 $Active = 'selected';
							 $Discarded = '';
							 $Completed = ''; 
						 }
						 else if($task == "Discarded" || $task == "Discarded")
						 {
							 $Active = '';
							 $Discarded = 'selected';
							 $Completed = '';
						 }
						 else if($task == "Completed" || $task == "Completed")
						 {
							 $Active = '';
							 $Discarded = '';
							 $Completed = 'selected';
						 }
                                						 
              }
        }

		
			
			
			
		
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Application No : <span style="color:#f39c12"><b><?php echo $appno?></b></span> 
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">				   					   
			       <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $id?>"/>
                   <div class="col-md-4">
			             <div class="form-group">
                           <label>IP</label>
                           <select class="form-control select2" name="ip" id="ip" style="width: 100%;">
								<option>-- Select IP--</option>
								<option value="PT" <?php echo $PT?>>Patent</option>
								<option value="CR" <?php echo $CR?>>Copywright</option>
								<option value="TM" <?php echo $TM?>>Trademark</option>
								<option value="DN" <?php echo $DN?>>Design</option>
                  
                </select>
              </div>
				   </div>
			       <div class="col-md-4">
			             <div class="form-group">
                           <label>Sub-IP</label>
                           <select class="form-control select2" name="sip" id="sip" style="width: 100%;">
								<option>-- Select IP--</option>
								<option value="New Application" <?php echo $NewApplication?>>New Application</option>
								<option value="Search" <?php echo $Search?>>Search</option>
								<option value="Renewal" <?php echo $Renewal?>>Renewal</option>
								<option value="Restoration" <?php echo $Restoration?>>Restoration</option>
								<option value="Others" <?php echo $Others?>>Others</option>
								<option value="Assignment" <?php echo $Assignment?>>Assignment</option>
                  
                </select>
              </div>
				   </div>
                   <div class="col-md-4">
			         <div class="form-group">
                        <label>Application No.</label>
                        <input type="text" class="form-control" id="appno" name="appno" value="<?php echo $appno?>"placeholder="Enter Applicant Name"/>
                     </div>
				   </div>				   
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-4">
			         <div class="form-group">
                        <label>Applicant</label>
                        <input type="text" class="form-control" id="applicant" name="applicant" value="<?php echo $applicant?>" placeholder="Enter Applicant Name"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $title?>" placeholder="Enter Title"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Filed On</label>
                        <input type="date" class="form-control" id="filedon" name="filedon" value="<?php echo $filedon?>" placeholder="Enter Filed On"/>
                     </div>
			       </div>
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-4">
			         <div class="form-group">
                        <label>Priority Date</label>
                        <input type="date" class="form-control" id="prioritydate" value="<?php echo $prioritydate?>" name="prioritydate" placeholder="Enter Priority Date"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Priority Country</label>
                        <input type="text" class="form-control" id="country" value="<?php echo $country?>" value="India" name="country" placeholder="Enter Country"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                           <label>Entity Status</label>
                           <select class="form-control select2" name="entity" id="entity" style="width: 100%;">
								<option>-- Select --</option>
								<option value="Individual / Micro" <?php echo $Individual?>>Individual / Micro</option>
								<option value="Small Entity" <?php echo $SmallEntity?>>Small Entity</option>
								<option value="Large Entity" <?php echo $LargeEntity?>>Large Entity</option>
								<option value="Law Firm" <?php echo $LawFirm?>>Law Firm</option>
								<option value="IP Firm" <?php echo $IPFirm?>>IP Firm</option>
                  
                </select>
              </div>
			       </div>
				   </div>
				   </div>
				   
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-4">
			             <div class="form-group">
                           <label>Status</label>
                           <select class="form-control select2" name="task" id="task" style="width: 100%;">
								<option value="Active" <?php echo $Active?>>Active</option>
								<option value="Discarded" <?php echo $Discarded?>>Discarded</option>
								<option value="Completed" <?php echo $Completed?>>Completed</option>
                  
                </select>
              </div>
				   </div>
			       <div class="col-md-8">
			          <div class="form-group">
                        <label>Remark</label>
                        <input type="text" class="form-control" id="remark" name="remark" value="<?php echo $remark?>" placeholder="Enter Remark"/>
                     </div>
			       </div>
			       
				   </div>
				   </div>
               
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="update" id="update" class="btn btn-success">Update</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
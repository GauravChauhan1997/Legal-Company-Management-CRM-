<?php include("header.php")?>
<?php

if(isset($_POST["update"]))
	 {
		    $id = $_POST["id"];
			$fullname = $_POST["fullname"];
			$email	 = $_POST["email"];
			$contact = $_POST["contact"];
			$address = $_POST["address"];
			$followup = $_POST["followup"];
			$enquirystatus = $_POST["enquirystatus"];

		 $query = "UPDATE `enquiry` SET `fullname`='$fullname',`email`='$email',`contact`='$contact',`address`='$address',`followup`='$followup',`enquirystatus`='$enquirystatus' WHERE enquiryid = '$id'";
		 
		 $que = mysql_query($query);
		 if($que)
		 {
			 echo'<script>alert("Enquiry Details Updated")</script>';
		 }
		 else{
			 echo'<script>alert("Something Went Wrong")</script>';
		 }

	 }


if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM enquiry WHERE `enquiryid` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["enquiryid"];
					        $fullname = $row_user["fullname"];
							$email	 = $row_user["email"];
							$contact = $row_user["contact"];
							$address = $row_user["address"];
							$followup = $row_user["followup"];
							$enquirystatus = $row_user["enquirystatus"];
							$status = $row_user["status"];
							$createdon = $row_user["createdon"];
					 
						 
						 if($enquirystatus == "Active" || $enquirystatus == "Active")
						 {
							 $Active = 'selected';
							 $Discarded = '';
							 $Completed = '';
						 }
						 else if($enquirystatus == "Discarded" || $enquirystatus == "Discarded")
						 {
							 $Active = '';
							 $Discarded = 'selected';
							 $Completed = '';
						 }
						 else if($enquirystatus == "Completed" || $enquirystatus == "Completed")
						 {
							 $Active = '';
							 $Discarded = '';
							 $Completed = 'selected';
						 }
						  						 
              }
        }

?>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Enquiry
        <small>Creation</small>
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">		
				   
			       <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $id?>"/>
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo $fullname?>" placeholder="Enter Full Name"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $email?>" placeholder="Enter Email ID"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="contact" name="contact" value="<?php echo $contact?>" placeholder="Enter Contact Number"/>
                     </div>
			       </div>
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo $address?>" placeholder="Enter address"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			         <div class="form-group">
                        <label>FollowUp Date</label>
                        <input type="date" class="form-control" id="followup" name="followup" value="<?php echo $followup?>" placeholder="Enter FollowUp Date"/>
                     </div>
				   </div>
			        <div class="col-md-4">
			          <div class="form-group">
                           <label>Status</label>
                           <select class="form-control select2" name="enquirystatus" id="enquirystatus" style="width: 100%;">
								<option value="Active" <?php echo $Active?>>Active</option>
								<option value="Discarded" <?php echo $Discarded?>>Discarded</option>
								<option value="Completed" <?php echo $Completed?>>Completed</option>
                  
                </select>
              </div>
			       </div>
			       
				   </div>
				   </div>
				   
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="update" id="update" class="btn btn-primary">Update</button>
				<button type="submit" class="btn btn-warning">Reset</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
<?php include("header.php")?>
 <?php
	$query2 = mysql_query("select count(*) as total2 from addnewclient WHERE newclientrefid = '$user_check' && clientstatus  = 'Active'");
	$row_user2 = mysql_fetch_assoc($query2);
	$client = $row_user2["total2"];
	
	$query3 = mysql_query("select count(*) as total3 from newdocket WHERE newdocketrefid= '$user_check'");
	$row_user3 = mysql_fetch_assoc($query3);
	$docket = $row_user3["total3"];
	
	$query4 = mysql_query("select count(*) as total4 from enquiry WHERE enquirystatus = 'Active'");
	$row_user4 = mysql_fetch_assoc($query4);
	$enquiry = $row_user4["total4"];
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <a href="existingclients.php"><div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-gear-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" style="color:black">Total Clients</span>
              <span class="info-box-number" style="color:black"><b><?php echo $client?></b></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div></a>
        <!-- /.col -->
        <a href="docket.php"><div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-google-plus"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" style="color:black">Total Dockets</span>
              <span class="info-box-number" style="color:black"><b><?php echo $docket?></b></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div></a>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <a href="activeenquires.php"><div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-cart-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" style="color:black">Total Enquires</span>
              <span class="info-box-number" style="color:black"><b><?php echo $enquiry?></b></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div></a>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">New Members</span>
              <span class="info-box-number">2,000</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  
<?php include("footer.php")?>
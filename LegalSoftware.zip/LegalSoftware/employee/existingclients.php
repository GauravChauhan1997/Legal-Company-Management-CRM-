<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM addnewclient WHERE `addnewclientid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Existing Clients
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th><input type="checkbox"/></th>
				  <th>Sr no</th>
                  <th>Client Name</th>
                  <th>Email</th>
                  <th>Contact</th>
				  <th>Created By</th>
				  <th>Created On</th>				  
                  <th>Client Code</th>				  
				  <th>Docs</th>
				  <th>Status</th>
                </tr>
                </thead>
                <tbody>

<?php
$count = 1;
$query = mysql_query("select * FROM addnewclient WHERE assign = '$user_check' && clientstatus  = 'Active' ORDER BY addnewclientid DESC");
while($row = mysql_fetch_array($query))
{
?>
                <tr>
				  <td><input type="radio" name="chkNumber" class="chkNumber" value="<?php echo $row["addnewclientid"]?>"></td>
				  <td><?php echo $count?></td>
                  <td><b><a href="existingclientsview.php?view=<?php echo $row["addnewclientid"]?>"><?php echo $row["cfname"]?> <?php echo $row["cfullname"]?> </a></b></td>
                  <td><?php echo $row["cemail"]?></td>
                  <td><?php echo $row["ccontact"]?></td>
				  <td><?php echo $row["createdby"]?></td>			  
                  <td><?php echo $row["ccreateddate"]?></td>
                  <td style="color:green"><b><?php echo $row["clientcode"]?></b></td>
				  <td>
				      <a href="AddImagesdetails3.php?view=<?php echo $row["addnewclientid"]?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
				  </td>
                  <td style="color:blue"><?php echo $row["clientstatus"]?></td>				  
                 
                </tr>
<?php
$count++;
}
?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php include("footer.php")?>
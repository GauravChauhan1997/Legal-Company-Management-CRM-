<?php include("header.php")?>
<?php
if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM newdocket WHERE `newdocketid` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["newdocketid"];
					        $newdocketid = $row_user["newdocketid"];
			}
		}
?>
<?php
if(isset($_POST["submit"]))
{
	$applicant = $_POST["applicant"];
	$title = $_POST["title"];
	$filedon = $_POST["filedon"];
	$prioritydate = $_POST["prioritydate"];
	$country = $_POST["country"];
	$entity = $_POST["entity"];
	$ip = $_POST["ip"];
	$sip = $_POST["sip"];
	$remark = $_POST["remark"];
	$docketno = $_POST["docketno"];
	$appno = $_POST["appno"];
	$task = $_POST["task"];
	$keyy = $_POST["keyy"];
	$status = '0';
	$createddate = date('d-M-Y');
	$createdon = date('d-M-Y');
	
	$io = mysql_query("select * from addnewemployee where addnewemployeeid = '$user_check'");
	$ty = mysql_fetch_assoc($io);
	$newcaserefid2 = $ty["addnewemployeeid"];
	$query = "INSERT INTO `newcase`(`applicant`, `title`, `filedon`, `prioritydate`, `country`, `entity`, `ip`, `sip`, `remark`, `appno`, `task`,`newcaserefid`, `newcaserefid2`,`keyy`,`status`, `createddate`, `createdon`) VALUES ('$applicant','$title','$filedon','$prioritydate','$country','$entity','$ip','$sip','$remark','$appno','$task','$newdocketid','$newcaserefid2','$keyy','$status','$createddate','$createdon')";
	$que = mysql_query($query);
	if($que)
	{
		echo '<script>alert ("New Case is Created")
		window.location.href = "docket.php";
		</script>';
	}else
	{
		echo '<script>alert ("Something Went Wrong")</script>';
	}
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Create New Case
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST" enctype="multipart/form-data">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">				   	
				   <input type="hidden" name="docketno" id="docketno"/>
				   <input type="hidden" name="keyy" id="keyy" value="<?php echo ' '.mt_rand(100,999)?>"/>	
                   <div class="col-md-4">
			             <div class="form-group">
                           <label>IP</label>
                           <select class="form-control" name="ip" id="ip" style="width: 100%;">
								<option>-- Select IP--</option>
								<option value="PT">Patent</option>
								<option value="CR">Copywright</option>
								<option value="TM">Trademark</option>
								<option value="DN">Design</option>
                  
                </select>
              </div>
				   </div>
			       <div class="col-md-4">
			             <div class="form-group">
                           <label>Sub-IP</label>
                           <select class="form-control" name="sip" id="sip" style="width: 100%;">
								<option>-- Select IP--</option>
								<option value="New Application">New Application</option>
								<option value="Search">Search</option>
								<option value="Renewal">Renewal</option>
								<option value="Restoration">Restoration</option>
								<option value="Others">Others</option>
								<option value="Assignment">Assignment</option>
                  
                </select>
              </div>
				   </div>
                   <div class="col-md-4">
			         <div class="form-group">
                        <label>Application No.</label>
                        <input type="text" class="form-control" id="appno" name="appno" placeholder="Enter Applicant Name"/>
                     </div>
				   </div>				   
			      
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				    <div class="col-md-4">
			         <div class="form-group">
                        <label>Applicant</label>
                        <input type="text" class="form-control" id="applicant" name="applicant" placeholder="Enter Applicant Name"/>
                     </div>
				   </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Filed On</label>
                        <input type="date" class="form-control" id="filedon" name="filedon" placeholder="Enter Filed On"/>
                     </div>
			       </div>
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Priority Date</label>
                        <input type="date" class="form-control" id="prioritydate" name="prioritydate" placeholder="Enter Priority Date"/>
                     </div>
				   </div>
			       
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Priority Country</label>
                        <input type="text" class="form-control" id="country" value="India" name="country" placeholder="Enter Country"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                           <label>Entity Status</label>
                           <select class="form-control" name="entity" id="entity" style="width: 100%;">
								<option>-- Select --</option>
								<option value="Individual / Micro">Individual / Micro</option>
								<option value="Small Entity">Small Entity</option>
								<option value="Large Entity">Large Entity</option>
								<option value="Law Firm">Law Firm</option>
								<option value="IP Firm">IP Firm</option>
                  
                </select>
              </div>
			       </div>
			      
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				    
                   <div class="col-md-4">
			          <div class="form-group">
                           <label>Status</label>
                           <select class="form-control" name="task" id="task" style="width: 100%;">
								<option value="Active">Active</option>
								<option value="Discarded">Discarded</option>
								<option value="Completed">Completed</option>
                  
                </select>
              </div>
			       </div>	
                   <div class="col-md-8">
			          <div class="form-group">
                        <label>Remark</label>
                        <textarea type="text" class="form-control" id="remark" name="remark" style="height:35px"></textarea>
                     </div>
			       </div>				   
				   </div>
				   </div>
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="submit" id="submit" class="btn btn-primary">Create</button>
				<button type="submit" class="btn btn-warning">Reset</button>
				
				<a href="docket.php"><button type="button" name="back" id="back" class="btn btn-info">Back</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
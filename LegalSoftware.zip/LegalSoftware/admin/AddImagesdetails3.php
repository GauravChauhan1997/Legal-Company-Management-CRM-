<?php include("header.php");?>
<?php
if(isset($_REQUEST["del"]) && isset($_REQUEST["del"]) != "")
{
	$del = $_REQUEST["del"];
	$DeleteQuery = mysql_query("delete from webgalleryimage3 where webgalleryimage3id = '$del'");
	if($DeleteQuery)
	{
		echo '<script>alert("Document Deleted Successfully")</script>';
	}
	else
	{
		echo '<script>alert("Sorry Something Went Wrong!!")</script>';
	}
}
?>
<script type="text/javascript">


</script>
<?php

if(isset($_POST["imgsub"]))
{
	$title = $_POST["title"];
	$webgalleryid = $_POST["webgalleryid"];
	$status = '0';
	$createddate = date('d-M-Y h:i:s');
	
	$itemcount = count($_POST["item_no"]);
	$que = 0;
			
	for($i = 0; $i < $itemcount; $i++)
 		
{
$tmpFilePath = $_FILES['fruit_img']['tmp_name'][$i];
 $shortname = $_FILES['fruit_img']['name'][$i];
 $filePath = "clientdocs/" . date('d-m-Y-H-i-s').'-'.$_FILES['fruit_img']['name'][$i];
if(move_uploaded_file($tmpFilePath, $filePath)) {

	$files[] = $shortname;
	//insert into db 
	//use $shortname for the filename
	//use $filePath for the relative url to the file

} 
	$query = "INSERT INTO `webgalleryimage3`(`title`,`photo`,`refwebgalleryimage`, `status`, `createddate`) VALUES ('$title[$i]','$filePath','$webgalleryid','$status','$createddate')";
	$que = mysql_query($query);
}
	if($que)
	{
		echo '<script>alert("Document is Uploaded")</script>';
	}else
		{
		echo '<script>alert("Something Went Wrong")</script>';
	}
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   



<style>
#divLoading
{
display : none;
}
#divLoading.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('http://loadinggif.com/images/image-selection/3.gif');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
#loadinggif.show
{
left : 50%;
top : 50%;
position : absolute;
z-index : 101;
width : 32px;
height : 32px;
margin-left : -16px;
margin-top : -16px;
}
div.content {
width : 1000px;
height : 1000px;
}
</style>
 <div id="divLoading" style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.8;">
<p style="position: absolute; color: White; top: 60%; left: 45%;">
Loading, please wait...
</p>
</div>
	<section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="box box-primary"><br>
                <div class="box-header with-border">
					<center><h3>Add Client Documents</h3></center>
                </div>
				<bR>
				
                <form method="post" action="" enctype="multipart/form-data">
				<div class="row">
				  <input type="hidden" name="webgalleryid" id="webgalleryid" value="<?php echo $_GET["view"] ?>"/>
							<div class="col-md-12">
							    <div class="col-md-2"></div>
								<div class="col-md-4">
								<input type="hidden" class="form-control ino" id="no_0" name="item_no[]" style="width:50px" value="1">
									<div class="form-group">
										<label>Document Title</label>
						               <input type="text" class="form-control" name="title[]" id="title_0" placeholder="Title"/>
						            </div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Attachment</label>
						                <input type="file" class="form-control" id="fruit_0" name="fruit_img[]" />
									</div>
								</div>
								<div class="col-md-2"></div>
								</div>
								<br>
								<div id="div"></div>
								
							<center>
													            </button>
							<button type="submit" name="imgsub" id="imgsub"  class="btn btn-success">Submit</button>
							<a href="existingclients.php"><button type="button"  class="btn btn-primary">Back</button></a></center>
							<br>								
					</div>
					</form>
					<hr>
					<div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
					  <th style="text-align:center">Sr No</th>
					  <th style="text-align:center">Document Title</th>
					  <th style="text-align:center">Attachments</th>
					  <th style="text-align:center">Action</th>
                  
                </tr>
                </thead>
                <tbody>
				<?php
					$count =1;
					$GetCandidateQuery = mysql_query("select * from webgalleryimage3 WHERE refwebgalleryimage = '".$_GET['view']."'");
					while($rows = mysql_fetch_array($GetCandidateQuery))
					{
				?>
				<tr>
                  <td style="text-align:center"><?php echO $count?></td>
                  <td style="text-align:center"><?php echo $rows["title"]?></td>
                 <td><center><a href="<?php echo $rows["photo"]?>" download>Download</center></td>
                 
                  <td style="text-align:center"> 
					<a href="#"> <i class="fa fa-times" aria-hidden="true" type="submit" style="color:red; font-size:20px" data-toggle="modal" data-target="#myModal13"></i></a>
					
				  </td>
                 
                  
                </tr>
                <?php
				$count++;
						}
				?>
                </tbody>
               
              </table>
            </div>
              </div>
            </div>
          </div>   <!-- /.row -->
	</section>
  </div>
    <?php
					$GetCandidateQuery2 = mysql_query("select * from webgalleryimage3 WHERE refwebgalleryimage = '".$_GET['view']."'");
					$rows2 = mysql_fetch_assoc($GetCandidateQuery2);
				
						
?>
  <div class="modal fade" id="myModal13" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color:red">Delete</h4>
        </div>
        <div class="modal-body">
          <p>Are you Sure, you Want to delete?</p>
        </div>
        <div class="modal-footer">
          <a href="AddImagesdetails3.php?del=<?php echo $rows2["webgalleryimage3id"]?>&view=<?php echo $rows2["refwebgalleryimage"]?>" style="color:white"><button type="button" class="btn btn-success"  id="delete">Yes</button></a>
					 
					 	 
		 <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
        </div>
      </div>
      
    </div>
  </div>
  
  <?php include("footer.php");?>
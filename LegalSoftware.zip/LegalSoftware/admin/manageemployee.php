<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM addnewemployee WHERE `addnewemployeeid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Manage Employees
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
			<a href="addemployee.php"><button type="button" style="margin:5px" class="btn btn-success" name="add" id="add">Add New Employee</button></a>
              
              <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#myModal12">Delete</button>
			  <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				<th><input type="checkbox"/></th>
				  <th>Sr no</th>
                  <th>Employee Name</th>
                  <th>Email</th>
                  <th>Contact</th>
				  <th>Department</th>
				  <th>Created On</th>				  
                  <th>Employee Code</th>
				  <th>Docs</th>
                </tr>
                </thead>
                <tbody>
<?php
$count = 1;
$query = mysql_query("select * FROM addnewemployee WHERE empid = '$user_check' ORDER BY addnewemployeeid DESC");
while($row = mysql_fetch_array($query))
{
?>
                <tr>
				
				  <td><input type="radio" name="chkNumber" class="chkNumber" value="<?php echo $row["addnewemployeeid"]?>"></td>
				  <td><?php echo $count?></td>
                  <td><b><a href="employeeview.php?view=<?php echo $row["addnewemployeeid"]?>"><?php echo $row["fname"]?> <?php echo $row["mname"]?> <?php echo $row["lname"]?></a></b></td>
                  <td><?php echo $row["email"]?></td>
                  <td><?php echo $row["contact"]?></td>
				  <td><?php echo $row["dept"]?></td>
                  <td><?php echo $row["createddate"]?></td>
                  <td style="color:green"><b style="text-transform: uppercase;"><?php echo $row["empcode"]?></b></td>				  
                  <td>
				      <a href="AddImagesdetails.php?view=<?php echo $row["addnewemployeeid"]?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
				  </td>
				  </td>
                </tr>
<?php
$count++;
}
?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>  
  
<?php
$query22 = mysql_query("select * FROM addnewemployee WHERE empid = '$user_check' ORDER BY addnewemployeeid DESC");
while($row22 = mysql_fetch_array($query22))
{
?>
  <div class="modal fade" id="myModal12" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color:red">Delete</h4>
        </div>
        <div class="modal-body">
          <p>Are you Sure, you Want to delete?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" id="delete" data-dismiss="modal">Yes</button> 		 
		 <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
        </div>
      </div>
      
    </div>
  </div> 
  <?php
}
?>
<?php include("footer.php")?>
<script>
 $(document).on("click","#delete",function(e){
		
			if ($('.chkNumber:checked').length) {
				  var chkId = '';
				  $('.chkNumber:checked').each(function () {
					chkId += $(this).val() + ",";
				  });
				  chkId = chkId.slice(0, -1);
				 //alert(chkId);
				 location.href = "manageemployee.php?del=" + chkId ;
				}
				else {
				  alert('Nothing Selected');
				}
			
		});
</script>
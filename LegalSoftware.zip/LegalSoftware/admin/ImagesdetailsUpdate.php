<?php include("header.php");?>

<?php
if(isset($_REQUEST["del"]) && isset($_REQUEST["del"]) != "")
{
	$del = $_REQUEST["del"];
	$DeleteQuery = mysql_query("delete from webgalleryimage where webgalleryimageid = '$del'");
	if($DeleteQuery)
	{
		echo '<script>alert("Document Deleted Successfully")</script>';
	}
	else
	{
		echo '<script>alert("Sorry Something Went Wrong!!")</script>';
	}
}
?>
<style>
#divLoading
{
display : none;
}
#divLoading.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('http://loadinggif.com/images/image-selection/3.gif');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
#loadinggif.show
{
left : 50%;
top : 50%;
position : absolute;
z-index : 101;
width : 32px;
height : 32px;
margin-left : -16px;
margin-top : -16px;
}
div.content {
width : 1000px;
height : 1000px;
}
</style>
 <div id="divLoading" style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.8;">
<p style="position: absolute; color: White; top: 60%; left: 45%;">
Loading, please wait...
</p>
</div>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

	<section class="content"> 
	<div class="row">
        <div class="col-xs-12">
		
		
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Document Details</h3>&nbsp;&nbsp;&nbsp;
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
					  <th style="text-align:center">Sr No</th>
					  <th style="text-align:center">Subject</th>
					  <th style="text-align:center">Document</th>
					  <th style="text-align:center">Action</th>
                  
                </tr>
                </thead>
                <tbody>
				<?php
					$count =1;
					$GetCandidateQuery = mysql_query("select * from webgalleryimage WHERE refwebgallery = '".$_GET['view']."'");
					while($rows = mysql_fetch_array($GetCandidateQuery))
					{
				?>
				<tr>
                  <td style="text-align:center"><?php echO $count?></td>
                  <td style="text-align:center"><?php echo $rows["title"]?></td>
                 <td><center><a href="<?php echo $rows["photo"]?>" download>Download</center></td>
                 
                  <td style="text-align:center"> 
					<a href="ImagesdetailsUpdate.php?del=<?php echo $rows["webgalleryimageid"]?>&view=<?php echo $rows["refwebgallery"]?>"<i class="fa fa-times" aria-hidden="true" type="submit" style="color:red; font-size:20px" id="delete" name="delete"></i></a>
					
				  </td>
                 
                  
                </tr>
                <?php
				$count++;
						}
				?>
                </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
      
      </div>
	</section>
  </div>
 <?php include("footer.php");?>
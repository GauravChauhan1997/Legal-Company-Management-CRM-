<?php include("header.php")?>
<?php
if(isset($_POST["submit"]))
{
$cfname = $_POST["cfname"];
$cfullname = $_POST["cfullname"];
$ccp = $_POST["ccp"];
$caddress = $_POST["caddress"];
$cbaddress = $_POST["cbaddress"];
$cemail = $_POST["cemail"];
$ccontact = $_POST["ccontact"];
$caltno = $_POST["caltno"];
$country = $_POST["country"];
$entity = $_POST["entity"];
$industry = $_POST["industry"];
$currency = $_POST["currency"];
$assign = $_POST["assign"];
$remarks = $_POST["remarks"];
$clientcode = $_POST["clientcode"];
$cstatus = '0';
$ccreateddate = date('d-M-Y');
$ccreatedon = date('d-M-Y');

$xyz = mysql_query("select * from login where id = '$user_check'");
$abcd = mysql_fetch_assoc($xyz);
$abc = $abcd["fullname"];
$query = "INSERT INTO `addnewclient`(`cfname`, `cfullname`, `ccp`, `caddress`, `cbaddress`,`cemail`, `ccontact`, `caltno`,`country`,`entity`, `industry`, `currency`, `assign`,
`remarks`, `clientcode`, `createdby`, `clientstatus`, `newclientrefid`, `cstatus`, `ccreateddate`, `ccreatedon`) VALUES ('$cfname','$cfullname','$ccp','$caddress','$cbaddress','$cemail','$ccontact','$caltno','$country','$entity','$industry','$currency','$assign','$remarks','$clientcode','$abc','Active','$user_check','$cstatus','$ccreateddate','$ccreatedon')";
$que = mysql_query($query);
if($que)
{
	echo '<script>alert ("New Client is Created") 
	 window.location.href = "existingclients.php";
	 </script>';
}else
{
	echo '<script>alert ("Something Went Wrong")</script>';
}

}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add New Client
        <small>Creation</small>
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">	
                 <div class="col-md-12">				   
				   <label>Company / Individual Name</label>				   
                 </div>				   
                    </div>
				   </div>
				   <div class="row" style="margin-top:5px">
				   <div class="col-md-12">	
				   <input type="hidden" name="clientcode" id="clientcode" value="<?php echo ''.mt_rand(10000,99999)?>"/>                  		   
			       <div class="col-md-2">
			         <div class="form-group">
                                               
						       <select class="form-control" name="cfname" id="cfname" style="width: 100%;">
								<option value="M/S">M/S</option>
								<option value="Mr.">Mr.</option>
								<option value="Mrs.">Mrs.</option>
								<option value="Ms.">Ms.</option>                
                                 </select>
						
					 </div>
				   </div>
			      <div class="col-md-6" style="margin-left:-31px">
			         <div class="form-group">
                                
						<input type="text" class="form-control" id="cfullname" name="cfullname" placeholder="Enter Full Name"/>
                     </div>
				   </div>
			      
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			        <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact Person</label>
                        <input type="text" class="form-control" id="ccp" name="ccp" placeholder="Enter Contact Number"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="cemail" name="cemail" placeholder="Enter Email ID"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="ccontact" name="ccontact" placeholder="Enter Contact Number"/>
                     </div>
			       </div>
				   
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Alternate Number</label>
                        <input type="text" class="form-control" id="caltno" name="caltno" placeholder="Enter Alternative No"/>
                     </div>
				   </div>
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Country</label>
                        <input type="text" class="form-control" id="country" name="country" placeholder="Enter Country Name"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			         <div class="form-group">
                           <label>Entity Status</label>
                           <select class="form-control" name="entity" id="entity" style="width: 100%;">
								<option>-- Select --</option>
								<option>Individual / Micro</option>
								<option>Small Entity</option>
								<option>Large Entity</option>
								<option>Law Firm</option>
								<option>IP Firm</option>
                  
                </select>
              </div>
				   </div>
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				    <div class="col-md-4">
			          <div class="form-group">
                        <label>Industry</label>
                        <input type="text" class="form-control" id="industry" name="industry" placeholder="Enter Industry"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Currency</label>
                        <input type="text" class="form-control" id="currency" name="currency" placeholder="Enter Currency"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			         <div class="form-group">
                           <label>Assign to</label>
                           <select class="form-control" name="assign" id="assign" style="width: 100%;">

<?php
$df = mysql_query("select * FROM addnewemployee");
while($docs = mysql_fetch_array($df))
{
?>

								<option value="<?php echo $docs["addnewemployeeid"]?>"><?php echo $docs["fname"]?> <?php echo $docs["lname"]?></option>
<?php
}
?>
								
                  
                </select>
              </div>
				   </div>
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-6">
			         <div class="form-group">
                        <label>Delivery Address</label>
                        <textarea type="text" class="form-control" id="caddress" style="height:100px" name="caddress"></textarea>
                     </div>
				   </div>
			       
			       <div class="col-md-6">
			          <div class="form-group">
                        <label>Bill to Address</label>
                        <textarea type="text" class="form-control" id="cbaddress" style="height:100px" name="cbaddress"></textarea>
                     </div>
			       </div>
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-12">
			         <div class="form-group">
                           <label>Remarks</label>
                           <textarea type="text" class="form-control" id="remarks" style="height:100px" name="remarks"></textarea>
                     </div>
				   </div>			      
				   </div>
				   </div>
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
				<a href="#"><button type="submit" class="btn btn-warning">Reset</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
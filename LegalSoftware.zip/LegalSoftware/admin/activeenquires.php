<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM enquiry WHERE `enquiryid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Manage Enquires
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
			<a href="addenquiry.php"><button type="button" style="margin:5px" class="btn btn-success" name="add" id="add">Add New Enquiry</button></a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Sr no</th>
                  <th>Full Name</th>
                  <th>Email</th>
                  <th>Contact</th>
				  <th>FollowUp Date</th>
				  <th>Created On</th>
                  <th>Created By</th>				  
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
<?php
$count = 1;
$query = mysql_query("select * FROM enquiry WHERE enquirystatus = 'Active' ORDER BY enquiryid DESC");
while($row = mysql_fetch_array($query))
{
?>
                <tr>
				  <td><?php echo $count?></td>
                  <td><b><a href="enquiryview.php?view=<?php echo $row["enquiryid"]?>"><?php echo $row["fullname"]?></a></b></td>
                  <td><?php echo $row["email"]?></td>
                  <td><?php echo $row["contact"]?></td>
				  <td><?php echo $row["followup"]?></td>
                  <td><?php echo $row["createddate"]?></td>
                  <td><?php echo $row["createdby"]?></td>
                  <td style="color:blue"><?php echo $row["enquirystatus"]?></td>				  
                  <!--td><a href="activeenquires.php?del=<?php echo $row["enquiryid"]?>"><i class="fa fa-times" aria-hidden="true" type="submit" style="color:red; font-size:20px" id="delete" name="delete"></i></a>
				  </td-->
                </tr>
<?php
$count++;
}
?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php include("footer.php")?>
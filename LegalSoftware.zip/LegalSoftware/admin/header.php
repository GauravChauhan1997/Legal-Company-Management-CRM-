<?php include("session.php")?>
<?php include("../libs/config.php")?>

<?php 
$query = mysql_query("select * FROM login where id = '$user_check'");
$row = mysql_fetch_assoc($query);
$name = $row["fullname"];
?>

<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

 

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini <?php if($_REQUEST['current'] == 'totalc') {echo "sidebar-collapse";}?>">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Admin</b>LTE</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="../index.php">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Logout</span>
            </a>
            
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>

    </nav>
  </header>

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><a href="index.php"><?php echo $name?></a></p>
          <a href="index.php"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <!--li class="active">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li-->
        <li class="<?php if($_REQUEST['current'] == 'dashboard') {echo "active";}?>">       
            <li class="<?php if($_REQUEST['current'] == 'dashboard') {echo "active";}?>"><a href="manageemployee.php?current=dashboard"><i class="fa fa-th"></i>Manage Employees</a></li>
       
        </li>
        		
        <li class="<?php if($_REQUEST['current'] == 'NewClient' || $_REQUEST['current'] == 'ExistingClients' || $_REQUEST['current'] == 'InactiveClients') {echo "active";}?> treeview">
          <a href="#">
            <i class="fa fa-edit"></i> <span>Client Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if($_REQUEST['current'] == 'NewClient') {echo "active";}?>"><a href="addnewclient.php?current=NewClient"><i class="fa fa-circle-o text-red"></i> Add New Client</a></li>
            <li class="<?php if($_REQUEST['current'] == 'ExistingClients') {echo "active";}?>"><a href="existingclients.php?current=ExistingClients"><i class="fa fa-circle-o text-yellow"></i> Existing Clients</a></li>
            <li class="<?php if($_REQUEST['current'] == 'InactiveClients') {echo "active";}?>"><a href="inactiveclients.php?current=InactiveClients"><i class="fa fa-circle-o text-aqua"></i> Inactive Clients</a></li>
          </ul>
        </li>
		 <li class="<?php if($_REQUEST['current'] == 'docket') {echo "active";}?> treeview">       
            <li class="<?php if($_REQUEST['current'] == 'docket') {echo "active";}?>"><a href="docket.php?current=docket"><i class="fa fa-th"></i> Dockets</a></li>
       
        </li>
		<!--li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i> <span>Docketing</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="docket.php"><i class="fa fa-circle-o text-red"></i>Dockets</a></li>
            <li><a href="cases.php"><i class="fa fa-circle-o text-yellow"></i> All Cases</a></li>
          </ul>
        </li-->
		<li class="<?php if($_REQUEST['current'] == 'Patent' || $_REQUEST['current'] == 'Trademark' || $_REQUEST['current'] == 'Design' || $_REQUEST['current'] == 'Copyright') {echo "active";}?> treeview">
          <a href="#">
            <i class="fa fa-folder"></i> <span>All Created Cases</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>

          <ul class="treeview-menu">
            <li class="<?php if($_REQUEST['current'] == 'Patent') {echo "active";}?>"><a href="Patent.php?current=Patent"><i class="fa fa-circle-o text-red"></i> Patent</a></li>
            <li class="<?php if($_REQUEST['current'] == 'Trademark') {echo "active";}?>"><a href="Trademark.php?current=Trademark"><i class="fa fa-circle-o text-yellow"></i> Trademark</a></li>
            <li class="<?php if($_REQUEST['current'] == 'Design') {echo "active";}?>"><a href="Design.php?current=Design"><i class="fa fa-circle-o text-aqua"></i> Design</a></li>
			<li class="<?php if($_REQUEST['current'] == 'Copyright') {echo "active";}?>"><a href="Copyright.php?current=Copyright"><i class="fa fa-circle-o text-green"></i> Copyright</a></li>
          </ul>
        </li>
        <li class="<?php if($_REQUEST['current'] == 'activetask' || $_REQUEST['current'] == 'discardedtask' || $_REQUEST['current'] == 'completedtask') {echo "active";}?> treeview">
          <a href="#">
            <i class="fa fa-book"></i> <span>Case Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if($_REQUEST['current'] == 'activetask') {echo "active";}?>"><a href="activetask.php?current=activetask"><i class="fa fa-circle-o text-red"></i> Active </a></li>
            <li class="<?php if($_REQUEST['current'] == 'discardedtask') {echo "active";}?>"><a href="discardedtask.php?current=discardedtask"><i class="fa fa-circle-o text-yellow"></i> Discarded </a></li>
            <li class="<?php if($_REQUEST['current'] == 'completedtask') {echo "active";}?>"><a href="completedtask.php?current=completedtask"><i class="fa fa-circle-o text-aqua"></i> Completed </a></li>
          </ul>
        </li>
		
		<li class="<?php if($_REQUEST['current'] == 'activeenquires' || $_REQUEST['current'] == 'discardedenquires' || $_REQUEST['current'] == 'completedenquires') {echo "active";}?> treeview">
          <a href="#">
            <i class="fa fa-laptop"></i> <span>Enquires</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if($_REQUEST['current'] == 'activeenquires') {echo "active";}?>"><a href="activeenquires.php?current=activeenquires"><i class="fa fa-circle-o text-red"></i> Active</a></li>
            <li class="<?php if($_REQUEST['current'] == 'discardedenquires') {echo "active";}?>"><a href="discardedenquires.php?current=discardedenquires"><i class="fa fa-circle-o text-yellow"></i> Discarded</a></li>
            <li class="<?php if($_REQUEST['current'] == 'completedenquires') {echo "active";}?>"><a href="completedenquires.php?current=completedenquires"><i class="fa fa-circle-o text-yellow"></i> Completed</a></li>
          </ul>
        </li>
        
        
        </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

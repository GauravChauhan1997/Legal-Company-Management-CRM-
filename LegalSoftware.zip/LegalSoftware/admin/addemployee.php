<?php include("header.php")?>

<?php
if(isset($_POST["submit"]))
{
$fname = $_POST["fname"];
$mname = $_POST["mname"];
$lname = $_POST["lname"];
$dob = $_POST["dob"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$address = $_POST["address"];
$email = $_POST["email"];
$contact = $_POST["contact"];
$altno = $_POST["altno"];
$nationality = $_POST["nationality"];
$location = $_POST["location"];
$city = $_POST["city"];
$dept = $_POST["dept"];
$pan = $_POST["pan"];
$aadhar = $_POST["aadhar"];
$relation = $_POST["relation"];
$father_name = $_POST["father_name"];
$f_mname = $_POST["f_mname"];
$f_lname = $_POST["f_lname"];
$f_email = $_POST["f_email"];
$f_contact = $_POST["f_contact"];
$faddress = $_POST["faddress"];
$designation = $_POST["designation"];
$password = $_POST["password"];
$empcode = $_POST["empcode"];
$empcode2 = $_POST["fname"];
$status = '0';
$createddate = date('d-M-Y');
$createdon = date('d-M-Y');
$characters = 'abc123';
		$string = '';
		$string1 = '';
		$string2 = '';
		$string6 = '';
			$profile_image = $_FILES["fruit_img"]["name"];
				
			if($profile_image <> "")
			{

				for($j = 0; $j < count($profile_image); $j++)
				{
					
				for($i = 0; $i < 0; $i++) {
					$string .= $characters[rand(0, strlen($characters) - 1)];
				}	
				$profile_imagePath = "empphoto/" . $string . $profile_image[$j];

				move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
				}	
			}	

$query = "INSERT INTO `addnewemployee`(`fname`, `mname`, `lname`, `dob`, `age`, `gender`, `address`, `email`, `contact`, `altno`, `nationality`, `location`, `city`, `dept`, `pan`, `aadhar`, `relation`, `father_name`, `f_mname`, `f_lname`, `f_email`, `f_contact`, `faddress`, `photo`, `designation`, `password`, `empcode`, `empcode2`, `usertype`, `empid`, `status`, `createddate`, `createdon`) 
VALUES 
('$fname','$mname','$lname','$dob','$age','$gender','$address','$email','$contact','$altno','$nationality','$location','$city','$dept','$pan','$aadhar','$relation','$father_name','$f_mname','$f_lname','$f_email','$f_contact','$faddress','$profile_imagePath','$designation','$password','$empcode','$empcode2','emp','$user_check','$status','$createddate','$createdon')";
$que = mysql_query($query);
if($que)
{
	echo '<script>alert("New Employee is Created") 
	 window.location.href = "manageemployee.php";
	 </script>';
}else
{
	echo '<script>alert ("Something Went Wrong")</script>';
}

}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add New Employee
        <small>Creation</small>
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST" enctype="multipart/form-data">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">		
				   <input type="hidden" name="empcode" id="empcode" value="<?php echo 'EMP'.mt_rand(100,999)?>"/>		   	
				   <input type="hidden" name="password" id="password" value="<?php echo ''.mt_rand(100000,999999)?>"/>		    
			       <div class="form-group col-md-3">
							<img src="pages/1313308622.jpg "id="blah" src="#" name=""  style="width:120px; height:120px;"/>
							<input type='file' id="imgInp" style="padding-top:5px" name="fruit_img[]"/>
                </div>
                <div class="form-group col-md-3" style="margin-top:20px">
                  <label>First Name</label>
                  <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter First Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Middle Name</label>
                  <input type="text" class="form-control" name="mname" id="mname" placeholder="Enter Middle Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Last name</label>
                  <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Last Name">
                </div>
				
				   </div>
				   </div>
				   
				   <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-2">
                          <label>D.O.B</label>
                          <input type="date" class="form-control" name="dob" id="dob" placeholder="D.O.B">
                    </div>
					<div class="form-group col-md-2">
                          <label>Age</label>
                          <input type="text" class="form-control" name="age" id="age" placeholder="Age">
                    </div>
                    <div class="form-group col-md-4">
                          <label>Gender</label><br>
                          <select class="form-control" name="gender" id="gender" style="width: 100%;">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
						  </select>
                    </div>
                     <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email ID"/>
                     </div>
			       </div>
			     </div>
			  </div>
				   
				   <div class="row">
				   <div class="col-md-12">
			      
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="contact" name="contact" placeholder="Enter Contact Number"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Alternate Number</label>
                        <input type="number" class="form-control" id="altno" name="altno" placeholder="Enter Alternative No."/>
                     </div>
			       </div>
				   <div class="form-group col-md-4">
                          <label>Nationality</label>
                          <select class="form-control" name="nationality" id="nationality" style="width:100%;">
								<option value="Indian">Indian</option>
								<option value="Foreign_National">Foreign National</option>
						  </select>
                    </div>
				   </div>
				   </div>
				   
				   <div class="row">
			     <div class="col-md-12">
			        
                    <div class="form-group col-md-4">
                          <label>Location</label><br>
                          <select class="form-control" name="location" id="location" style="width: 100%;">
								<option value="Kalyan">Kalyan</option>
								<option value="Thane">Thane</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>City</label>
                          <select class="form-control" name="city" id="city" style="width: 100%;">
								<option value="Mumbai">Mumbai</option>
								<option value="Navi Mumbai">Navi Mumbai</option>
						  </select>
                    </div>
					 <div class="col-md-4">
			          <div class="form-group">
                        <label>Designation</label>
                        <input type="text" class="form-control" id="designation" name="designation" placeholder="Enter Designation"/>
                     </div>
			       </div>
			     </div>
			  </div>
				   
				   <div class="row">
				   <div class="col-md-12">
			       <div class="form-group col-md-4">
                          <label>Department</label><br>
                          <select class="form-control" name="dept" id="dept" style="width: 100%;">
								<option value="Patent">Patent</option>
								<option value="Trademark/Copyright">Trademark/Copyright</option>
								<option value="Design">Design</option>
								<option value="Admin">Admin</option>
								<option value="Accounts">Accounts</option>
								<option value="Litigation">Litigation</option>
								<option value="Consulting">Consulting</option>
						  </select>
                    </div>
			      <div class="col-md-4">
			          <div class="form-group">
                        <label>Pan No</label>
                        <input type="text" class="form-control" id="pan" name="pan" placeholder="Enter Pan No"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Aadhar No</label>
                        <input type="text" class="form-control" id="aadhar" name="aadhar" placeholder="Enter Aadhar No"/>
                     </div>
			       </div>
				   
				   </div>
				   </div>
				   <div class="row">
			     <div class="col-md-12">
				 <div class="col-md-4">
			        <div class="form-group">
                        <label>Address</label>
                        <textarea type="text" class="form-control" id="address" style="height:95px" name="address" placeholder="Enter Address"></textarea>
                     </div>
                   </div>
			     </div>
			  </div>
                <h2 style="margin-left:12px"></b>Family Details</b></h2><br>
			  <div class="row">
			       <div class="col-md-12">
				        <div class="form-group col-md-3">
                          <label>Relation</label><br>
                          <select class="form-control" name="relation" id="relation" style="width: 100%;">
								<option value="Father">Father</option>
								<option value="Mother">Mother</option>
								<option value="Spouse">Spouse</option>
								<option value="Gaurdian ">Gaurdian </option>
						  </select>
                    </div>
					</div>
				</div>
				<div class="row">
				    <div class="col-md-12">
						<div class="form-group col-md-4">
						<label>First Name</label><br>
						  <input type="text" class="form-control" name="father_name" id="father_name" placeholder="First Name">
						</div>
						<div class="form-group  col-md-4">
						<label>Middle Name</label><br>
						  <input type="text" class="form-control" name="f_mname" id="f_mname" placeholder="Middle Name">
						</div>
						<div class="form-group  col-md-4">
						<label>Last Name</label><br>
						  <input type="text" class="form-control" name="f_lname" id="f_lname" placeholder="Last Name">
						</div>
						
					</div>
			  </div>
			   <div class="row">
			       <div class="col-md-12">
				        
						
						
						<div class="form-group  col-md-4">
						<label>Email</label><br>
						  <input type="text" class="form-control" name="f_email" id="f_email" placeholder="Email">
						</div>
						<div class="form-group  col-md-4">
						<label>Contact No</label><br>
						  <input type="text" class="form-control" name="f_contact" id="f_contact" placeholder="Contact No">
						</div>
						<div class="form-group  col-md-4">
						</div>
					</div>
			  </div>
			  <div class="row">
			       <div class="col-md-12">
				        <div class="form-group  col-md-4">
						<label>Address</label><br>
						  <textarea type="text" class="form-control" id="faddress" style="height:95px" name="faddress" placeholder="Enter Address"></textarea>
                     </div>
						
						</div>
			  </div>
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
				<a 
				href="#"><button type="button" class="btn btn-warning">Reset</button></a>
				<a href="manageemployee.php"><button type="button" class="btn btn-info">Back</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
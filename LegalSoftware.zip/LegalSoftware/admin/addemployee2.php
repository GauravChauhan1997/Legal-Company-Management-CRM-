<?php include("header.php")?>

<?php
if(isset($_POST["submit"]))
{
$fname = $_POST["fname"];
$mname = $_POST["mname"];
$lname = $_POST["lname"];
$address = $_POST["address"];
$email = $_POST["email"];
$contact = $_POST["contact"];
$altno = $_POST["altno"];
$designation = $_POST["designation"];
$password = $_POST["password"];
$empcode = $_POST["empcode"];
$empcode2 = $_POST["fname"];
$status = '0';
$createddate = date('d-M-Y');
$createdon = date('d-M-Y');

$query = "INSERT INTO `addnewemployee`(`fname`, `mname`, `lname`, `address`, `email`, `contact`, `altno`,`designation`, `password`, `empcode`, `empcode2`, `usertype`, `empid`, `status`, `createddate`, `createdon`) VALUES ('$fname','$mname','$lname','$address','$email','$contact','$altno','$designation','$password','$empcode','$empcode2','emp','$user_check','$status','$createddate','$createdon')";
$que = mysql_query($query);
if($que)
{
	echo '<script>alert ("New Employee is Created")</script>';
}else
{
	echo '<script>alert ("Something Went Wrong")</script>';
}

}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add New Employee
        <small>Creation</small>
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">		
				   <input type="hidden" name="empcode" id="empcode" value="<?php echo 'EMP'.mt_rand(100,999)?>"/>		   	
				   <input type="hidden" name="password" id="password" value="<?php echo ''.mt_rand(100000,999999)?>"/>		    
			       <div class="col-md-4">
			         <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter First Name"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" class="form-control" id="mname" name="mname" placeholder="Enter Middle Name"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" id="lname" name="lname" placeholder="Enter Last Name"/>
                     </div>
			       </div>
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email ID"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="contact" name="contact" placeholder="Enter Contact Number"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Alternative Number</label>
                        <input type="number" class="form-control" id="altno" name="altno" placeholder="Enter Alternative No."/>
                     </div>
			       </div>
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Designation</label>
                        <input type="text" class="form-control" id="designation" name="designation" placeholder="Enter Designation"/>
                     </div>
			       </div>
				    <div class="col-md-8">
			         <div class="form-group">
                        <label>Address</label>
                        <textarea type="text" class="form-control" id="address" style="height:35px" name="address" placeholder="Enter Address"></textarea>
                     </div>
				   </div>
				   </div>
				   </div>
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
				<button type="button" class="btn btn-warning">Reset</button>
				<a href="manageemployee.php"><button type="button" class="btn btn-info">Back</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
<?php include("header.php")?>
<?php

if(isset($_POST["update"]))
	 {
		    $id = $_POST["id"];
			$cfname = $_POST["cfname"];
			$cfullname = $_POST["cfullname"];
			$ccp = $_POST["ccp"];
			$caddress = $_POST["caddress"];
            $cbaddress = $_POST["cbaddress"];
			$cemail = $_POST["cemail"];
			$ccontact = $_POST["ccontact"];
            $caltno = $_POST["caltno"];
			$country = $_POST["country"];
			$entity = $_POST["entity"];
			$industry = $_POST["industry"];
			$currency = $_POST["currency"];
			$assign = $_POST["assign"];
			$remarks = $_POST["remarks"];
			$createdby = $_POST["createdby"];
			$clientstatus = $_POST["clientstatus"];

		 $query = "UPDATE `addnewclient` SET `cfname`='$cfname',`cfullname`='$cfullname',`ccp`='$ccp',`caddress`='$caddress',`cbaddress`='$cbaddress',`cemail`='$cemail',`ccontact`='$ccontact',`caltno`='$caltno',`country`='$country',`entity`='$entity',`industry`='$industry',`currency`='$currency',`assign`='$assign',`remarks`='$remarks',`createdby`='$createdby',`clientstatus`='$clientstatus' WHERE addnewclientid = '$id'";
		 
		 $que = mysql_query($query);
		 if($que)
		 {
			 echo'<script>alert("Client Details Updated") 
			  window.location.href = "existingclients.php";
			  </script>';
		 }
		 else{
			 echo'<script>alert("Something Went Wrong")</script>';
		 }

	 }


if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM addnewclient WHERE `addnewclientid` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["addnewclientid"];
					        $cfname = $row_user["cfname"];
							$cfullname = $row_user["cfullname"];
							$ccp = $row_user["ccp"];
							$caddress = $row_user["caddress"];
							$cbaddress = $row_user["cbaddress"];
							$cemail = $row_user["cemail"];
							$ccontact = $row_user["ccontact"];
							$caltno = $row_user["caltno"];
							$country = $row_user["country"];
							$entity = $row_user["entity"];
							$industry = $row_user["industry"];
							$currency = $row_user["currency"];
							$remarks = $row_user["remarks"];
							$createdby = $row_user["createdby"];
							$clientcode = $row_user["clientcode"];
							$cstatus = $row_user["cstatus"];
							$ccreatedon = $row_user["ccreatedon"];
					 
						 if($entity == "Individual / Micro")
						 {
							 $Individual = 'selected';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
						 else if($entity == "Small Entity" || $entity == "Small Entity")
						 {
							 $Individual = '';
							 $SmallEntity = 'selected';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
                         else if($entity == "Large Entity" || $entity == "Large Entity")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = 'selected';                       
							 $LawFirm = '';
							 $IPFirm = '';
						 }
                         else if($entity == "Law Firm" || $entity == "Law Firm")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = 'selected';
							 $IPFirm = '';
						 }
                         else if($entity == "IP Firm" || $entity == "IP Firm")
						 {
							 $Individual = '';
							 $SmallEntity = '';
							 $LargeEntity = '';                       
							 $LawFirm = '';
							 $IPFirm = 'selected';
						 }
						 if($cfname == "M/S" || $cfname == "M/S")
						 {
							 $ms = 'selected';
							 $mr = '';
							 $mrs = '';                       
							 $mss = '';
						 }
						 else if($cfname == "Mr." || $cfname == "Mr.")
						 {
							 $ms = '';
							 $mr = 'selected';
							 $mrs = '';                       
							 $mss = '';
						 }
						 else if($cfname == "Mrs." || $cfname == "Mrs.")
						 {
							 $ms = '';
							 $mr = '';
							 $mrs = 'selected';                       
							 $mss = '';
						 }
						 else if($cfname == "Ms." || $cfname == "Ms.")
						 {
							 $ms = '';
							 $mr = '';
							 $mrs = '';                       
							 $mss = 'selected';
						 }
                         						 
              }
        }

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Client Code : <span style="color:#f39c12"><b><?php echo $clientcode?></b></span>
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST">
              <div class="box-body">
			  <div class="row" style="margin-top:5px">
				   <div class="col-md-12">	
                 <div class="col-md-12">				   
				   <label>Company / Individual Name</label>				   
                 </div>				   
                    </div>
				   </div>
				   <div class="row" style="margin-top:5px">
				   <div class="col-md-12">					   
			       <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $id?>"/>	
				   <input type="hidden" name="clientcode" id="clientcode" value="<?php echo ''.mt_rand(10000,99999)?>"/>                  		   
			       <div class="col-md-2">
			         <div class="form-group">
                                               
						       <select class="form-control" name="cfname" id="cfname" style="width: 100%;">
								<option value="M/S" <?php echo $ms?>>M/S</option>
								<option value="Mr." <?php echo $mr?>>Mr.</option>
								<option value="Mrs." <?php echo $mrs?>>Mrs.</option>
								<option value="Ms." <?php echo $mss?>>Ms.</option>                
                                 </select>
						
					 </div>
				   </div>
			      <div class="col-md-6" style="margin-left:-31px">
			         <div class="form-group">
                                
						<input type="text" class="form-control" id="cfullname" name="cfullname" placeholder="Enter Full Name" value="<?php echo $cfullname?>"/>
                     </div>
				   </div>
			      
				   </div>
				   </div>
			       
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact Person</label>
                        <input type="text" class="form-control" id="ccp" name="ccp" placeholder="Enter Contact Number" value="<?php echo $cfullname?>"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="cemail" name="cemail" placeholder="Enter Email ID" value="<?php echo $cemail?>"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="ccontact" name="ccontact" placeholder="Enter Contact Number" value="<?php echo $ccontact?>"/>
                     </div>
			       </div>
				   
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Alternative Number</label>
                        <input type="text" class="form-control" id="caltno" name="caltno" placeholder="Enter Alternative No" value="<?php echo $caltno?>"/>
                     </div>
				   </div>
				   <div class="col-md-4">
			         <div class="form-group">
                        <label>Country</label>
                        <input type="text" class="form-control" id="country" name="country" placeholder="Enter Country Name" value="<?php echo $country?>"/>
                     </div>
				   </div>
			       <div class="col-md-4">
			         <div class="form-group">
                           <label>Entity Status</label>
                           <select class="form-control" name="entity" id="entity" style="width: 100%;">
								<option value="Individual / Micro" <?php echo $Individual?>>Individual / Micro</option>
								<option value="Small Entity" <?php echo $SmallEntity?>>Small Entity</option>
								<option value="Large Entity" <?php echo $LargeEntity?>>Large Entity</option>
								<option value="Law Firm" <?php echo $LawFirm?>>Law Firm</option>
								<option value="IP Firm" <?php echo $IPFirm?>>IP Firm</option>
                  
                           </select>
              </div>
				   </div>
			       
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Industry</label>
                        <input type="text" class="form-control" id="industry" name="industry" placeholder="Enter Industry" value="<?php echo $industry?>"/>
                     </div>
			       </div>
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Currency</label>
                        <input type="text" class="form-control" id="currency" name="currency" placeholder="Enter Currency" value="<?php echo $currency?>"/>
                     </div>
			       </div>
                   <div class="col-md-4">
			          <div class="form-group">
                        <label>Created By</label>
                        <input type="text" class="form-control" readonly id="createdby" name="createdby" placeholder="Enter Created By" value="<?php echo $createdby?>"/>
                     </div>
			       </div>	
                   					   
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-4">
			         <div class="form-group">
                           <label>Assign to</label>
                           <select class="form-control" name="assign" id="assign" style="width: 100%;">

<?php
$df = mysql_query("select * FROM addnewemployee");
while($docs = mysql_fetch_array($df))
{
?>

								<option value="<?php echo $docs["addnewemployeeid"]?>"><?php echo $docs["fname"]?> <?php echo $docs["lname"]?></option>
<?php
}
?>
								
                  
                </select>
              </div>
				   </div>	
                   <div class="col-md-4">
			          <div class="form-group">
                        <label>Client Status</label>
                        <select class="form-control" name="clientstatus" id="clientstatus" style="width: 100%;">
								<option>Active</option>
								<option>Inactive</option>
                  
                        </select>
                     </div>
			       </div>					   
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
				   <div class="col-md-6">
			         <div class="form-group">
                        <label>Client Address</label>
                        <input type="text" class="form-control" id="caddress"  name="caddress" value="<?php echo $caddress?>"/>
                     </div>
				   </div>
			       
			       <div class="col-md-6">
			          <div class="form-group">
                        <label>Bill to Address</label>
                        <input type="text" class="form-control" id="cbaddress" name="cbaddress" value="<?php echo $cbaddress?>"/>
                     </div>
			       </div>
			       
				   </div>
				   </div>
				   <div class="row">
				   <div class="col-md-12">
			       <div class="col-md-12">
			         <div class="form-group">
                           <label>Remarks</label>
                           <input type="text" class="form-control" id="remarks"  name="remarks" value="<?php echo $remarks?>"/>
                     </div>
				   </div>			      
				   </div>
				   </div>
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="update" id="update" class="btn btn-success">Update</button>
				<a href="existingclients.php"><button type="button" name="back" id="back" class="btn btn-info">Back</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>
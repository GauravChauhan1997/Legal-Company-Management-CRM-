<?php include("header.php")?>
<?php

if(isset($_POST["update"]))
	 {
		    $id = $_POST["id"];
			$fname = $_POST["fname"];
$mname = $_POST["mname"];
$lname = $_POST["lname"];
$dob = $_POST["dob"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$address = $_POST["address"];
$email = $_POST["email"];
$contact = $_POST["contact"];
$altno = $_POST["altno"];
$nationality = $_POST["nationality"];
$location = $_POST["location"];
$city = $_POST["city"];
$dept = $_POST["dept"];
$pan = $_POST["pan"];
$aadhar = $_POST["aadhar"];
$relation = $_POST["relation"];
$father_name = $_POST["father_name"];
$f_mname = $_POST["f_mname"];
$f_lname = $_POST["f_lname"];
$f_email = $_POST["f_email"];
$f_contact = $_POST["f_contact"];
$faddress = $_POST["faddress"];
$designation = $_POST["designation"];
$password = $_POST["password"];
$characters = 'abc123';
		$string = '';
		$string1 = '';
		$string2 = '';
		$string6 = '';
			$profile_image = $_FILES["fruit_img"]["name"];
				
			if($profile_image <> "")
			{

				for($j = 0; $j < count($profile_image); $j++)
				{
					
				for($i = 0; $i < 0; $i++) {
					$string .= $characters[rand(0, strlen($characters) - 1)];
				}	
				$profile_imagePath = "empphoto/" . $string . $profile_image[$j];

				move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
				}	
			}

		 $query = "UPDATE `addnewemployee` SET `fname`='$fname',`mname`='$mname',`lname`='$lname',`dob`='$dob',`age`='$age',`gender`='$gender',`address`='$address',`email`='$email',`contact`='$contact',`altno`='$altno',`nationality`='$nationality',`location`='$location',`city`='$city',`dept`='$dept',`pan`='$pan',`aadhar`='$aadhar',`relation`='$relation',`father_name`='$father_name',`f_mname`='$f_mname',`f_lname`='$f_lname',`f_email`='$f_email',`f_contact`='$f_contact',`faddress`='$faddress',`photo`='$profile_imagePath',`designation`='$designation',`password`='$password' WHERE addnewemployeeid = '$id'";
		 
		 $que = mysql_query($query);
		 if($que)
		 {
			 echo'<script>alert("Employee Details Updated") 
			  window.location.href = "manageemployee.php";
			  </script>';
		 }
		 else{
			 echo'<script>alert("Something Went Wrong")</script>';
		 }

	 }


if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM addnewemployee WHERE `addnewemployeeid` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			while($row_user = mysql_fetch_array($details))
			{
				            $id = $row_user["addnewemployeeid"];
					        $fname = $row_user["fname"];
							$mname = $row_user["mname"];
							$lname = $row_user["lname"];
							$dob = $row_user["dob"];
$age = $row_user["age"];
$gender = $row_user["gender"];
$address = $row_user["address"];
$email = $row_user["email"];
$contact = $row_user["contact"];
$altno = $row_user["altno"];
$nationality = $row_user["nationality"];
$location = $row_user["location"];
$city = $row_user["city"];
$dept = $row_user["dept"];
$pan = $row_user["pan"];
$aadhar = $row_user["aadhar"];
$relation = $row_user["relation"];
$father_name = $row_user["father_name"];
$f_mname = $row_user["f_mname"];
$f_lname = $row_user["f_lname"];
$f_email = $row_user["f_email"];
$f_contact = $row_user["f_contact"];
$faddress = $row_user["faddress"];
$photo = $row_user["photo"];
$designation = $row_user["designation"];
$password = $row_user["password"];

							$empcode = $row_user["empcode"];
							$status = $row_user["status"];
							$createdon = $row_user["createdon"];
					 
                         if($gender == "Male")
						 {
							 $Male = 'selected';
							 $Female = '';
						 }
                         else if($gender == "Female")
						 {
							 $Male = '';
							 $Female = 'selected';
						 }
                         
                         if($nationality == "Indian")
						 {
							 $Indian = 'selected';
							 $Foreign_National = '';
						 }
                         else if($nationality == "Foreign_National")
						 {
							 $Indian = '';
							 $Foreign_National = 'selected';
						 }

                         if($location == "Kalyan")
						 {
							 $Kalyan = 'selected';
							 $Thane = '';
						 }
                         else if($location == "Thane")
						 {
							 $Kalyan = '';
							 $Thane = 'selected';
						 }

                         if($city == "Mumbai")
						 {
							 $Mumbai = 'selected';
							 $Navi_Mumbai = '';
						 }
                         else if($city == "Navi Mumbai")
						 {
							 $Mumbai = '';
							 $Navi_Mumbai = 'selected';
						 }

                         if($dept == "Patent")
						 {
							 $patent = 'selected';
							 $trademark = '';
							 $design = '';
							 $admin = '';
							 $accounts = '';
							 $litigation = '';
							 $consulting = '';
						 }
                         else if($dept == "Trademark/Copyright")
						 {
							 $patent = '';
							 $trademark = 'selected';
							 $design = '';
							 $admin = '';
							 $accounts = '';
							 $litigation = '';
							 $consulting = '';
						 }						 
					     else if($dept == "Design")
						 {
							 $patent = '';
							 $trademark = '';
							 $design = 'selected';
							 $admin = '';
							 $accounts = '';
							 $litigation = '';
							 $consulting = '';
						 }
						 else if($dept == "Admin")
						 {
							 $patent = '';
							 $trademark = '';
							 $design = '';
							 $admin = 'selected';
							 $accounts = '';
							 $litigation = '';
							 $consulting = '';
						 }
						 else if($dept == "Accounts")
						 {
							 $patent = '';
							 $trademark = '';
							 $design = '';
							 $admin = '';
							 $accounts = 'selected';
							 $litigation = '';
							 $consulting = '';
						 }
						 else if($dept == "Litigation")
						 {
							 $patent = '';
							 $trademark = '';
							 $design = '';
							 $admin = '';
							 $accounts = '';
							 $litigation = 'selected';
							 $consulting = '';
						 }
						 else if($dept == "Consulting")
						 {
							 $patent = '';
							 $trademark = '';
							 $design = '';
							 $admin = '';
							 $accounts = '';
							 $litigation = '';
							 $consulting = 'selected';
						 }
						 
						 if($relation == "Father")
						 {
							 $Father = 'selected';
							 $Mother = '';
							 $Spouse = '';
							 $Gaurdian = '';
						 }
                         else if($relation == "Mother")
						 {
							 $Father = '';
							 $Mother = 'selected';
							 $Spouse = '';
							 $Gaurdian = '';
						 }
						 else if($relation == "Spouse")
						 {
							 $Father = '';
							 $Mother = '';
							 $Spouse = 'selected';
							 $Gaurdian = '';
						 }
						 else if($relation == "Gaurdian")
						 {
							 $Father = '';
							 $Mother = '';
							 $Spouse = '';
							 $Gaurdian = 'selected';
						 }
             }
        }

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee Code : <span style="color:#f39c12"><b style="text-transform: uppercase;"><?php echo $empcode?></b></span> / 
		Password : <span style="color:#f39c12"><b style="text-transform: uppercase;"><?php echo $password?></b></span>
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form method="POST" enctype="multipart/form-data">
              <div class="box-body">
			       <div class="row" style="margin-top:5px">
				   <div class="col-md-12">		
				   <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $id?>"/>		  
			       <div class="form-group col-md-3">
							<img src="<?php echo $photo?>" id="blah" src="#" name=""  style="width:120px; height:120px;"/>
							<input type='file' id="imgInp" style="padding-top:5px" name="fruit_img[]"/>
                </div>
                <div class="form-group col-md-3" style="margin-top:20px">
                  <label>First Name</label>
                  <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter First Name" value="<?php echo $fname?>"/>
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Middle Name</label>
                  <input type="text" class="form-control" name="mname" id="mname" placeholder="Enter Middle Name" value="<?php echo $mname?>"/>
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Last name</label>
                  <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Last Name" value="<?php echo $lname?>"/>
                </div>				
				   </div>		
				   </div>
				   
				   <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-2">
                          <label>D.O.B</label>
                          <input type="date" class="form-control" name="dob" id="dob" placeholder="D.O.B" value="<?php echo $dob?>">
                    </div>
					<div class="form-group col-md-2">
                          <label>Age</label>
                          <input type="text" class="form-control" name="age" id="age" placeholder="Age" value="<?php echo $age?>">
                    </div>
                    <div class="form-group col-md-4">
                          <label>Gender</label><br>
                          <select class="form-control" name="gender" id="gender" style="width: 100%;">
								<option value="Male" <?php echo $Male?>>Male</option>
								<option value="Female" <?php echo $Female?>>Female</option>
						  </select>
                    </div>
                     <div class="col-md-4">
			          <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email ID" value="<?php echo $email?>"/>
                     </div>
			       </div>
			     </div>
			  </div>
				   
				   <div class="row">
				   <div class="col-md-12">
			      
			       <div class="col-md-4">
			          <div class="form-group">
                        <label>Contact</label>
                        <input type="number" class="form-control" id="contact" name="contact" placeholder="Enter Contact Number" value="<?php echo $contact?>"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Alternate Number</label>
                        <input type="number" class="form-control" id="altno" name="altno" placeholder="Enter Alternative No." value="<?php echo $altno?>"/>
                     </div>
			       </div>
				   <div class="form-group col-md-4">
                          <label>Nationality</label>
                          <select class="form-control" name="nationality" id="nationality" style="width:100%;">
								<option value="Indian" <?php echo $Indian?>>Indian</option>
								<option value="Foreign_National" <?php echo $Foreign_National?>>Foreign National</option>
						  </select>
                    </div>
				   </div>
				   </div>
				   
				   <div class="row">
			     <div class="col-md-12">
			        
                    <div class="form-group col-md-4">
                          <label>Location</label><br>
                          <select class="form-control" name="location" id="location" style="width: 100%;">
								<option value="Kalyan" <?php echo $Kalyan?>>Kalyan</option>
								<option value="Thane" <?php echo $Thane?>>Thane</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>City</label>
                          <select class="form-control" name="city" id="city" style="width: 100%;">
								<option value="Mumbai" <?php echo $Mumbai?>>Mumbai</option>
								<option value="Navi Mumbai" <?php echo $Navi_Mumbai?>>Navi Mumbai</option>
						  </select>
                    </div>
					 <div class="col-md-4">
			          <div class="form-group">
                        <label>Designation</label>
                        <input type="text" class="form-control" id="designation" name="designation" value="<?php echo $designation?>" placeholder="Enter Designation"/>
                     </div>
			       </div>
			     </div>
			  </div>
				   
				   <div class="row">
				   <div class="col-md-12">
			       <div class="form-group col-md-4">
                          <label>Department</label><br>
                          <select class="form-control" name="dept" id="dept" style="width: 100%;">
								<option value="Patent" <?php echo $patent?>>Patent</option>
								<option value="Trademark/Copyright" <?php echo $trademark?>>Trademark/Copyright</option>
								<option value="Design" <?php echo $design?> >Design</option>
								<option value="Admin" <?php echo $admin?> >Admin</option>
								<option value="Accounts" <?php echo $accounts?> >Accounts</option>
								<option value="Litigation" <?php echo $litigation?> >Litigation</option>
								<option value="Consulting" <?php echo $consulting?> >Consulting</option>
						  </select>
                    </div>
			      <div class="col-md-4">
			          <div class="form-group">
                        <label>Pan No</label>
                        <input type="text" class="form-control" id="pan" name="pan" value="<?php echo $pan?>" placeholder="Enter Pan No"/>
                     </div>
			       </div>
				   <div class="col-md-4">
			          <div class="form-group">
                        <label>Aadhar No</label>
                        <input type="text" class="form-control" id="aadhar" name="aadhar" value="<?php echo $aadhar?>" placeholder="Enter Aadhar No"/>
                     </div>
			       </div>
				   
				   </div>
				   </div>
				   
				   <div class="row">
			     <div class="col-md-12">
				 <div class="col-md-4">
			        <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" id="address"  value="<?php echo $address?>" name="address" placeholder="Enter Address"/>
                     </div>
                   </div>
			     </div>
			  </div>
			  
			  <h2 style="margin-left:12px"></b>Family Details</b></h2><br>
			  <div class="row">
			       <div class="col-md-12">
				        <div class="form-group col-md-3">
                          <label>Relation</label><br>
                          <select class="form-control" name="relation" id="relation" style="width: 100%;">
								<option value="Father" <?php echo $Father?>>Father</option>
								<option value="Mother" <?php echo $Mother?>>Mother</option>
								<option value="Spouse" <?php echo $Spouse?>>Spouse</option>
								<option value="Gaurdian" <?php echo $Gaurdian?>>Gaurdian </option>
						  </select>
                    </div>
					</div>
				</div>
			  
			    <div class="row">
				    <div class="col-md-12">
						<div class="form-group col-md-4">
						<label>First Name</label><br>
						  <input type="text" class="form-control" name="father_name" id="father_name" value="<?php echo $father_name?>" placeholder="First Name">
						</div>
						<div class="form-group  col-md-4">
						<label>Middle Name</label><br>
						  <input type="text" class="form-control" name="f_mname" id="f_mname" value="<?php echo $f_mname?>" placeholder="Middle Name">
						</div>
						<div class="form-group  col-md-4">
						<label>Last Name</label><br>
						  <input type="text" class="form-control" name="f_lname" id="f_lname" value="<?php echo $f_lname?>" placeholder="Last Name">
						</div>
						
					</div>
			  </div>
			   <div class="row">
			       <div class="col-md-12">
				        
						
						
						<div class="form-group  col-md-4">
						<label>Email</label><br>
						  <input type="text" class="form-control" name="f_email" id="f_email" value="<?php echo $f_email?>" placeholder="Email">
						</div>
						<div class="form-group  col-md-4">
						<label>Contact No</label><br>
						  <input type="text" class="form-control" name="f_contact" id="f_contact" value="<?php echo $f_contact?>" placeholder="Contact No">
						</div>
						<div class="form-group  col-md-4">
						</div>
					</div>
			  </div>
			  <div class="row">
			       <div class="col-md-12">
				        <div class="form-group  col-md-4">
						<label>Address</label><br>
						  <input type="text" class="form-control" id="faddress" value="<?php echo $faddress?>" name="faddress" placeholder="Enter Address"/	>
                     </div>
						<div class="col-md-4">
			          <div class="form-group">
                        <label>Password</label>
                        <input type="text" class="form-control" id="password" name="password" placeholder="Enter password" value="<?php echo $password?>"/>
                     </div>
			       </div>
						</div>
			  </div>
				   
	
                
              </div>
                 
             
              <!-- /.box-body -->

              <div class="box-footer">
                <center>
				<button type="submit" name="update" id="update" class="btn btn-success">Update</button>
				
				<a href="manageemployee.php"><button type="button" name="back" id="back" class="btn btn-info">Back</button></a>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include("footer.php")?>